public class Product{
    
    private String p1 = "Laptop A"; //we have 9 available 
    private String p2 = "Laptop B"; // we have 10 available
    private String p3  ="Laptop C"; // we have 11 available
    private String p4 = "Laptop D"; // we have 12 available
    
   
  public Product(String p1 ,String p2,String p3 ,String p4){
      this.p1 = p1 ; //product1 Laptop A 
      this.p2 = p2 ; //product2 Laptop B
      this.p3 = p3 ; //product3 Laptop C
      this.p4 = p4 ; //product4 laptop D
  }
  public String getP1(){ 
      return p1 ; 
  }
  public String getP2(){
      return p2 ; 
  }
  public String getP3(){
      return p3 ; 
  }
  public String getP4(){
      return p4 ; 
  }
}
 class Order{
  
   String orderNum1 ; //"00H44" ;//for laptop A
   String orderNum2 ; // "00M44" ;//for laptop B
   String orderNum3 ; // "
   String orderNum4 ;
  public Order(){ 
   }
 }
 class Stock{
    private int productA ; 
    private int productB ; 
    private int productC ; 
    private int productD  ;
    public Stock(int productA ,int productB ,int productC , int productD ){
       this.productA = productA ; 
       this.productB = productB ;
       this.productC = productC ;
       this.productD = productD;
    }
    public int getProductA(){
      return productA ; 
  }
  public int getProductB(){
      return  productB; 
  }
  public int getProductC(){
      return productC ; 
  }
  public int getProductD(){
      return  productD; 
  }
 }
  class Prices{
      double price1 ;//price of laptop 1
      double price2 ; //price of laptop 2
      double price3; //price of laptop 3
      double price4; // price of laptop 4
      public Prices(double price1 ,double price2 , double price3 , double price4 ){
         this.price1 = price1;
         this.price2 = price2 ;
         this.price3 = price3 ;
         this.price4 = price4 ;
      }
  }
 